var jungle, monkey 
var jungleImage, monkey_running, stoneImage, bananaImage, bananasGroup, stonesGroup
var score = 0;
var wall1


//making the function for preload
function preload(){
  jungleImage = loadImage("jungle.jpg");
  monkey_running = loadAnimation("Monkey_01.png", "Monkey_02.png", "Monkey_03.png",
                              "Monkey_04.png", "Monkey_05.png", "Monkey_06.png", 
                              "Monkey_07.png", "Monkey_08.png", "Monkey_09.png", 
                              "Monkey_10.png");
  stoneImage = loadImage("stone.png");
  bananaImage = loadImage("banana.png"); 
}
function setup() {
  createCanvas(800, 400);
  bananasGroup = new Group();
  stonesGroup = new Group();
  
  
  ground = createSprite(0,0,800, 800);
  ground.addImage("jungle", jungleImage);
  ground.x = ground.width/1.5;
  ground.velocityX = -5;
  ground.scale = 2;
  
monkey = createSprite(100, 400, 70, 50);
  monkey.addAnimation("monkeyRunning", monkey_running);
  monkey.scale = 0.1;
  //making the bottom wall
  wall1 = createSprite(200, 400, 400, 1);
  wall1.visible = false;
}

function draw() {
  //background(220);
  monk();
 stone();
  banana();
 monkey.collide(wall1); 
  createEdgeSprites();

  //making the controls 
   
  if (ground.x < 0){
    ground.x = ground.width/2;
  }
  stroke("white");
  textSize(20);
  fill("white");
  text("SCORE: ", score, 500, 50);
  monkey.velocityY = 0.8;
 
  drawSprites();
  fill("white")
 text("Score: "+ score, 500,50);
  
  fill("black")
  textSize(20);
  
  //adding controls to the game
  if(keyDown("space")&&monkey.y>=200) {
      monkey.velocityY = -20;
  
    }
  //adding the gravity in the game 
  monkey.velocityY = monkey.velocityY+4;
  
}


//making the function for stone
function stone(){
  if(frameCount%200==0){

    var stone1 = createSprite(800, 380, 20, 20);
    stone1.addImage(stoneImage);
    stone1.scale = 0.1;
    stone1.velocityX = -5;
    stone1.lifetime = 200;
    stonesGroup.add(stone1);
  }
}
    
 //making the function for banana
function banana(){
if(frameCount%75===0){
  var banana1 = createSprite(800, 200, 20, 20);
  banana1.addImage(bananaImage);
  banana1.scale = 0.05;
  banana1.lifetime = 200;
  bananasGroup.add(banana1);
  banana1.y = Math.round(random(100, 250));
  banana1.velocityX = -7;
  
}
}
//making the funcition for monkey
function monk(){
  
  if(bananasGroup.isTouching(monkey)){
    score = score+2
    bananasGroup.destroyEach(); 
}
  //creating switch case increase the size of monkey
   switch(score){
        case 10: monkey.scale=0.12;
                break;
        case 20: monkey.scale=0.14;
                break;
        case 30: monkey.scale=0.16;
                break;
        case 40: monkey.scale=0.18;
                break;
        default: break;
    }
  //if monkey will touch the stone then 
  if(stonesGroup.isTouching(monkey)){ 
        monkey.scale=0.08;
     
    }
}